
WHILE 1 = 1
BEGIN
    DELETE TOP (10000)
    FROM Tramite.ExpedienteDocumentoOrigenDestinoTemporal d WITH (ROWLOCK)
    WHERE d.FechaCreacionAuditoria >= '20220101' AND d.FechaCreacionAuditoria <  '20230101'

    IF @@ROWCOUNT = 0 BREAK

    CHECKPOINT
    WAITFOR DELAY '00:00:00.1'
END
